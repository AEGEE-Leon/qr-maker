Las imágenes del centro de los códigos QR están disponibles aquí:
 - https://www.canva.com/design/DAGx0s_7rsY/fZfj3gSCNGs4EhWNVfynfA/edit
